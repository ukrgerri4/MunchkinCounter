
using Xamarin.Forms.Platform.Android;
using Xamarin.Forms;
using RoundedCornerEntry.CustomRenderers;
using RoundedCornerEntry.Droid.Renderers;

[assembly: ExportRenderer(typeof(CustomEntry), typeof(CustomEntryRenderer))]

namespace RoundedCornerEntry.Droid.Renderers
{
    public class CustomEntryRenderer : EntryRenderer
    {
        // Override the OnElementChanged method so we can tweak this renderer post-initial setup
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (Control != null)
            {
                this.Control.Background = this.Resources.GetDrawable(Resource.Drawable.RoundedCornerEntry);
            }
        }
    }
}