﻿
using Xamarin.Forms;

namespace RoundedCornerEntry.CustomRenderers
{
    public class CustomEntry : Entry { }
}

